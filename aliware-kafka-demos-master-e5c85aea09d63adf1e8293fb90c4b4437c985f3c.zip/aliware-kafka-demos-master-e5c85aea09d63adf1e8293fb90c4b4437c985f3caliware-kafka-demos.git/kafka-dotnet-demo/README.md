### 接入说明

DotNet建议使用Confluenct开源和维护的客户端，地址：https://github.com/confluentinc/confluent-kafka-dotnet
该客户端与Node.js客户端一样，实际上是包装[C++客户端](https://github.com/edenhill/librdkafka)实现的。因此可以参考NodeJs Demo的配置方式进行调试。




