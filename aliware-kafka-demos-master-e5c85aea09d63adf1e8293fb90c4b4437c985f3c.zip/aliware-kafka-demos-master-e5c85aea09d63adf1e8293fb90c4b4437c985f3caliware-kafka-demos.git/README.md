### [消息队列 Kafka](https://www.aliyun.com/product/kafka) Demos
这里提供各种接入 [消息队列 Kafka](https://www.aliyun.com/product/kafka) 的demo，方便开发者快速上手。
目前客户端demo包括 **Java**，**Python**，**Go**，**Logstash**，**SpringCloud**，其它客户端暂时请参照已有demo自行调试，后续会陆续完善。

各个客户端demo的目录通常如下：
- beta(公测demo,废弃)
- vpc(vpc实例接入demo)
- vpc-ssl(公网ssl实例接入demo)

商业化参考文档[快速入门](https://help.aliyun.com/document_detail/99949.html?spm=a2c4g.11186623.6.554.2be1c453UXdc4D) 


### [阿里云镜像地址](https://code.aliyun.com/alikafka/aliware-kafka-demos)
### [github镜像地址](https://github.com/AliwareMQ/aliware-kafka-demos)