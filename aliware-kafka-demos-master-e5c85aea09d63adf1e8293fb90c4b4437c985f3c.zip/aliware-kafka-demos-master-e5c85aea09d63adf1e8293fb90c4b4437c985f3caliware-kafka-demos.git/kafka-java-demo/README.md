# demo
请根据购买的实例信息选择相应的demo验证。
```
├── README.md
├── beta
│   ├── README.md
│   ├── pom.xml
│   ├── run_consumer.sh
│   ├── run_producer.sh
│   └── src
├── vpc
│   ├── README.md
│   ├── pom.xml
│   ├── build.sh
│   └── src
└── vpc-ssl
    ├── README.md
    ├── pom.xml
    ├── run_consumer.sh
    ├── run_producer.sh
    └── src
```

## beta
公测实例使用demo，废弃。

## vpc
商业化vpc实例使用默认接入点接入demo。

## vpc-ssl
商业化公网实例使用ssl接入点接入demo。

