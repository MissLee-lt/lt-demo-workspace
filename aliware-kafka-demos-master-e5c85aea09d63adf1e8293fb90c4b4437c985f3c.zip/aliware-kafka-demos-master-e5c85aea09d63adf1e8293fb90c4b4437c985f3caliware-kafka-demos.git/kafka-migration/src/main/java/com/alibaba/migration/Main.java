package com.alibaba.migration;

public class Main {
    public static void main(String[] args) {
        new Migration().run(args);
    }
}
