<?php

return [
    'sasl_plain_username' => 'xxx',
    'sasl_plain_password' => 'xxx',
    'bootstrap_servers' => "xxx:xx,xxx:xx",
    'topic_name' => 'xxx',
    'consumer_id' => 'xxx'
];
