kafka_setting = {
    'bootstrap_servers': 'xxx:xx,xxx:xx',
    'topic_name': 'xxx',
    'group_name': 'xxx'
}
