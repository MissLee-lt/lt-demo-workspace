rm ./kafka_consumer  ./kafka_producer
